<!-- ---
!-- title: 2025-01-03 00:12:31
!-- author: ywata-note-win
!-- date: /home/ywatanabe/proj/llemacs/workspace/projects/000-sample-project/README.md
!-- --- -->